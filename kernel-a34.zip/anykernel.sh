### AnyKernel3 Ramdisk Mod Script
## osm0sis @ xda-developers (adaptado para Galaxy A34 5G por Sami)

### AnyKernel setup
# global properties
properties() { '
kernel.string=CustomKernel A34 by sami
do.devicecheck=1
do.modules=0
do.systemless=1
do.cleanup=1
do.cleanuponabort=0
device.name1=a34x
device.name2=
device.name3=
supported.versions=
supported.patchlevels=
supported.vendorpatchlevels=
'; } # end properties

### AnyKernel install
## ramdisk attributes
init_boot_attributes() {
  set_perm_recursive 0 0 755 644 $RAMDISK/*;
  set_perm_recursive 0 0 750 750 $RAMDISK/init* $RAMDISK/sbin;
} # end attributes

# shell variables
BLOCK=init_boot;
IS_SLOT_DEVICE=1;
RAMDISK_COMPRESSION=auto;
PATCH_VBMETA_FLAG=auto;

# import core functions
. tools/ak3-core.sh;

# start patching
dump_boot; # unpack init_boot (Android 12+)

# opcional: modifica archivos del ramdisk si es necesario, por ejemplo:
# backup_file init.rc;
# replace_string init.rc "algo_original" "algo_modificado";

write_boot; # repack y escribe init_boot.img
## end init_boot install

### vendor_kernel_boot (si lo necesitas para dtb)
#BLOCK=vendor_kernel_boot;
#IS_SLOT_DEVICE=1;
#RAMDISK_COMPRESSION=auto;
#PATCH_VBMETA_FLAG=auto;

#. tools/ak3-core.sh;
#split_boot; # extrae kernel + dtb, sin tocar ramdisk
#flash_boot; # flashea el nuevo vendor_kernel_boot.img
## end vendor_kernel_boot install

